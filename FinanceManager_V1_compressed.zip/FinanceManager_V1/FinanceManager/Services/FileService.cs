using System.IO;
using System.Globalization;
using FinanceManager.Models;
using System;
using System.Collections.Generic;
using System.Linq;



namespace FinanceManager.Services;

// Veškerá práce se soubory – AppData, načítání, ukládání, export
public class FileService
{
    private readonly string _appDataPath;
    private readonly string _transactionsFile;
    private readonly string _categoriesFile;

    public FileService()
    {
        // Ukládáme data do %AppData%\FinanceManager\
        _appDataPath = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
            "FinanceManager");
        Directory.CreateDirectory(_appDataPath);

        _transactionsFile = Path.Combine(_appDataPath, "transactions.txt");
        _categoriesFile   = Path.Combine(_appDataPath, "categories.txt");

        // Vytvoříme prázdné soubory, pokud ještě neexistují
        if (!File.Exists(_transactionsFile))
            File.WriteAllText(_transactionsFile, "");

        if (!File.Exists(_categoriesFile))
            File.WriteAllLines(_categoriesFile, new[]
            {
                "Jídlo", "Bydlení", "Doprava", "Zábava",
                "Zdraví", "Oblečení", "Vzdělání", "Ostatní"
            });
    }

    // ── Transakce ──────────────────────────────────────────
    public List<Transaction> LoadTransactions()
    {
        var list = new List<Transaction>();
        foreach (var line in File.ReadAllLines(_transactionsFile))
        {
            if (string.IsNullOrWhiteSpace(line)) continue;
            var t = Transaction.FromFileLine(line);
            if (t != null) list.Add(t);
        }
        return list;
    }

    public void SaveTransactions(IEnumerable<Transaction> transactions)
        => File.WriteAllLines(_transactionsFile,
               transactions.Select(t => t.ToFileLine()));

    // ── Kategorie ──────────────────────────────────────────
    public List<string> LoadCategories()
        => File.Exists(_categoriesFile)
            ? File.ReadAllLines(_categoriesFile)
                  .Where(l => !string.IsNullOrWhiteSpace(l)).ToList()
            : new List<string> { "Ostatní" };

    public void SaveCategories(IEnumerable<string> cats)
        => File.WriteAllLines(_categoriesFile, cats);

    // ── Export do TXT na plochu ────────────────────────────
    public string ExportSummary(IEnumerable<Transaction> transactions)
    {
        var list    = transactions.ToList();
        var incomes = list.Where(t => t.Type == TransactionType.Income).ToList();
        var expenses= list.Where(t => t.Type == TransactionType.Expense).ToList();
        decimal totalIn  = incomes.Sum(t => t.Amount);
        decimal totalOut = expenses.Sum(t => t.Amount);

        var lines = new List<string>
        {
            "=== PŘEHLED FINANCÍ ===",
            $"Datum exportu: {DateTime.Now:dd.MM.yyyy HH:mm}",
            "", "--- PŘÍJMY ---"
        };
        foreach (var t in incomes)
            lines.Add($"{t.Date:dd.MM.yyyy}  {t.Category,-14}  {t.Description,-30}  +{t.Amount.ToString("N2", CultureInfo.CurrentCulture)} Kč");
        lines.Add($"Celkem příjmy: {totalIn:N2} Kč");

        lines.Add(""); lines.Add("--- VÝDAJE ---");
        foreach (var t in expenses)
            lines.Add($"{t.Date:dd.MM.yyyy}  {t.Category,-14}  {t.Description,-30}  -{t.Amount.ToString("N2", CultureInfo.CurrentCulture)} Kč");
        lines.Add($"Celkem výdaje: {totalOut:N2} Kč");

        lines.Add(""); lines.Add("--- SOUHRN ---");
        lines.Add($"Příjmy:  {totalIn:N2} Kč");
        lines.Add($"Výdaje:  {totalOut:N2} Kč");
        lines.Add($"Bilance: {(totalIn - totalOut):N2} Kč");

        var dest = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.Desktop),
            $"finance_export_{DateTime.Now:yyyyMMdd_HHmm}.txt");
        File.WriteAllLines(dest, lines);
        return dest;
    }
}
