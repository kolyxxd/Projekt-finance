using System;
using System.Collections.Generic;
using System.Linq;
using FinanceManager.Models;

namespace FinanceManager.Services;

// Aplikační logika – veškeré výpočty a správa transakcí
public class FinanceService
{
    private readonly FileService _fileService;
    private List<Transaction> _transactions;

    public FinanceService(FileService fileService)
    {
        _fileService  = fileService;
        _transactions = _fileService.LoadTransactions();
    }

    public IReadOnlyList<Transaction> GetAll()        => _transactions.AsReadOnly();
    public decimal TotalIncome()  => _transactions.Where(t => t.Type == TransactionType.Income).Sum(t => t.Amount);
    public decimal TotalExpense() => _transactions.Where(t => t.Type == TransactionType.Expense).Sum(t => t.Amount);
    public decimal Balance()      => TotalIncome() - TotalExpense();
    public bool    IsInProfit()   => Balance() >= 0;

    public void Add(Transaction t)
    {
        _transactions.Add(t);
        _fileService.SaveTransactions(_transactions);
    }

    public void Delete(Guid id)
    {
        _transactions.RemoveAll(t => t.Id == id);
        _fileService.SaveTransactions(_transactions);
    }

    // Výdaje seskupené podle kategorií (pro statistiky)
    public Dictionary<string, decimal> ExpensesByCategory()
        => _transactions
            .Where(t => t.Type == TransactionType.Expense)
            .GroupBy(t => t.Category)
            .ToDictionary(g => g.Key, g => g.Sum(t => t.Amount));
}
