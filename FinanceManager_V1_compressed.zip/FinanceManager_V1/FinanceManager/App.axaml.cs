using Avalonia;
using Avalonia.Controls.ApplicationLifetimes;
using Avalonia.Markup.Xaml;
using FinanceManager.Views;
using FinanceManager.ViewModels;
using FinanceManager.Services;

namespace FinanceManager;

public partial class App : Application
{
    public override void Initialize() => AvaloniaXamlLoader.Load(this);

    public override void OnFrameworkInitializationCompleted()
    {
        if (ApplicationLifetime is IClassicDesktopStyleApplicationLifetime desktop)
        {
            // Inicializace sdílených služeb
            var fileService = new FileService();
            var financeService = new FinanceService(fileService);

            desktop.MainWindow = new MainWindow(financeService, fileService);
        }
        base.OnFrameworkInitializationCompleted();
    }
}
