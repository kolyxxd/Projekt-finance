using Avalonia.Controls;

namespace FinanceManager.Views;

public partial class StatisticsWindow : Window
{
    public StatisticsWindow() => InitializeComponent();
}
