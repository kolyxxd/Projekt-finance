using Avalonia.Controls;

namespace FinanceManager.Views;

// Code-behind je prázdný – veškerá logika je v AddTransactionViewModel
public partial class AddTransactionWindow : Window
{
    public AddTransactionWindow() => InitializeComponent();
}
