using Avalonia.Controls;
using FinanceManager.Services;
using FinanceManager.ViewModels;

namespace FinanceManager.Views;

public partial class MainWindow : Window
{
    private readonly FinanceService _finance;
    private readonly FileService    _files;

    public MainWindow(FinanceService finance, FileService files)
    {
        _finance = finance;
        _files   = files;

        var vm = new MainWindowViewModel(finance, files);
        vm.OpenAddWindow   = OpenAddTransaction;
        vm.OpenStatsWindow = OpenStatistics;
        vm.ShowMsg         = msg => ShowInfo(msg);

        DataContext = vm;
        InitializeComponent();
    }

    // Otevře modální okno pro přidání transakce
    private async void OpenAddTransaction()
    {
        if (DataContext is not MainWindowViewModel vm) return;
        var addVm = new AddTransactionViewModel(_finance, _files);
        addVm.OnSaved = () => vm.Refresh();

        var win = new AddTransactionWindow { DataContext = addVm };
        addVm.CloseWindow = win.Close;
        await win.ShowDialog(this);
    }

    // Otevře okno statistik
    private async void OpenStatistics()
    {
        var win = new StatisticsWindow { DataContext = new StatisticsViewModel(_finance) };
        await win.ShowDialog(this);
    }

    // Zobrazí jednoduchý informační dialog
    private async void ShowInfo(string message)
    {
        var dialog = new Window
        {
            Title  = "Info",
            Width  = 420,
            Height = 140,
            WindowStartupLocation = WindowStartupLocation.CenterOwner,
            Content = new TextBlock
            {
                Text         = message,
                Margin       = new Avalonia.Thickness(20),
                TextWrapping = Avalonia.Media.TextWrapping.Wrap,
                VerticalAlignment = Avalonia.Layout.VerticalAlignment.Center
            }
        };
        await dialog.ShowDialog(this);
    }
}
