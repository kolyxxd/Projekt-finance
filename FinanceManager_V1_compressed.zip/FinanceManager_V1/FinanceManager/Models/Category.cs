using System;
namespace FinanceManager.Models;

// Kategorie výdaje / příjmu
public class Category
{
    public string Name { get; set; } = "";
    public Category() { }
    public Category(string name) => Name = name;
    public override string ToString() => Name;
}
