using System;
using Avalonia.Media;
using Avalonia.Media;

namespace FinanceManager.Models;

// Typ transakce: příjem nebo výdaj
public enum TransactionType { Income, Expense }

// Jedna finanční transakce
public class Transaction
{
    public Guid   Id          { get; set; } = Guid.NewGuid();
    public string Description { get; set; } = "";
    public decimal Amount     { get; set; }
    public TransactionType Type { get; set; }
    public string Category    { get; set; } = "Ostatní";
    public DateTime Date      { get; set; } = DateTime.Now;

    // Pomocné vlastnosti pro zobrazení v UI bez potřeby IValueConverter
    public string DisplayAmount =>
        Type == TransactionType.Expense
            ? $"−{Amount:N2} Kč"
            : $"+{Amount:N2} Kč";

    // Barva částky: červená = výdaj, zelená = příjem
    public IBrush AmountColor =>
        Type == TransactionType.Expense
            ? new SolidColorBrush(Color.Parse("#c62828"))
            : new SolidColorBrush(Color.Parse("#2e7d32"));

    // Serializace do TXT: ID|Popis|Částka|Typ|Kategorie|Datum
    public string ToFileLine() =>
        $"{Id}|{Description}|{Amount.ToString(System.Globalization.CultureInfo.InvariantCulture)}|{Type}|{Category}|{Date:yyyy-MM-dd}";

    // Deserializace z řádku TXT souboru
    public static Transaction? FromFileLine(string line)
    {
        var p = line.Split('|');
        if (p.Length != 6) return null;
        try
        {
            return new Transaction
            {
                Id          = Guid.Parse(p[0]),
                Description = p[1],
                Amount      = decimal.Parse(p[2], System.Globalization.CultureInfo.InvariantCulture),
                Type        = Enum.Parse<TransactionType>(p[3]),
                Category    = p[4],
                Date        = DateTime.Parse(p[5])
            };
        }
        catch { return null; }
    }
}
