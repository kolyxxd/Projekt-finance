using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.Windows.Input;
using FinanceManager.Models;
using FinanceManager.Services;
using System.Linq;
using FinanceManager.ViewModels;

// ViewModel pro formulář přidání transakce + validace vstupů
public class AddTransactionViewModel : INotifyPropertyChanged
{
    private readonly FinanceService _finance;

    // ── Vstupní pole formuláře ──────────────────────────────
    private string _description = "";
    public string Description
    {
        get => _description;
        set { _description = value; Notify(nameof(Description)); }
    }

    private string _amountText = "";
    public string AmountText
    {
        get => _amountText;
        set { _amountText = value; Notify(nameof(AmountText)); }
    }

    private bool _isExpense = true;
    public bool IsExpense
    {
        get => _isExpense;
        set { _isExpense = value; Notify(nameof(IsExpense)); Notify(nameof(IsIncome)); }
    }
    public bool IsIncome
    {
        get => !_isExpense;
        set { _isExpense = !value; Notify(nameof(IsExpense)); Notify(nameof(IsIncome)); }
    }

    private string _selectedCategory = "Ostatní";
    public string SelectedCategory
    {
        get => _selectedCategory;
        set { _selectedCategory = value; Notify(nameof(SelectedCategory)); }
    }

    public List<string> Categories { get; }

    // ── Chybová zpráva ─────────────────────────────────────
    private string _errorMessage = "";
    public string ErrorMessage
    {
        get => _errorMessage;
        private set { _errorMessage = value; Notify(nameof(ErrorMessage)); Notify(nameof(HasError)); }
    }
    public bool HasError => !string.IsNullOrEmpty(ErrorMessage);

    public ICommand SaveCommand   { get; }
    public ICommand CancelCommand { get; }

    // Callbacky nastavené z View
    public Action?  CloseWindow { get; set; }
    public Action?  OnSaved     { get; set; }

    public AddTransactionViewModel(FinanceService finance, FileService files)
    {
        _finance   = finance;
        Categories = files.LoadCategories();
        if (Categories.Any()) SelectedCategory = Categories.First();

        SaveCommand   = new RelayCommand(_ => TrySave());
        CancelCommand = new RelayCommand(_ => CloseWindow?.Invoke());
    }

    // Validace a uložení – vrátí false při chybě
    private void TrySave()
    {
        // Validace popisu
        if (string.IsNullOrWhiteSpace(Description))
        {
            ErrorMessage = "Popis nesmí být prázdný.";
            return;
        }

        // Validace částky
        if (!decimal.TryParse(AmountText.Replace(',', '.'),
                System.Globalization.NumberStyles.Any,
                System.Globalization.CultureInfo.InvariantCulture,
                out decimal amount) || amount <= 0)
        {
            ErrorMessage = "Zadej platnou kladnou částku (např. 250 nebo 99.90).";
            return;
        }

        ErrorMessage = ""; // Žádná chyba – vymažeme

        _finance.Add(new Transaction
        {
            Description = Description.Trim(),
            Amount      = amount,
            Type        = IsExpense ? TransactionType.Expense : TransactionType.Income,
            Category    = SelectedCategory,
            Date        = DateTime.Now
        });

        OnSaved?.Invoke();
        CloseWindow?.Invoke();
    }

    public event PropertyChangedEventHandler? PropertyChanged;
    private void Notify(string n) =>
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(n));
}
