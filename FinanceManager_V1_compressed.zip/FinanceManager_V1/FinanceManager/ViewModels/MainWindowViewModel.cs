using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Windows.Input;
using FinanceManager.Models;
using FinanceManager.Services;

namespace FinanceManager.ViewModels;

// Hlavní ViewModel – drží seznam transakcí a statistiky pro hlavní okno
public class MainWindowViewModel : INotifyPropertyChanged
{
    private readonly FinanceService _finance;
    private readonly FileService    _files;

    // Seznam transakcí zobrazený v UI (seřazeno od nejnovějšího)
    public ObservableCollection<Transaction> Transactions { get; } = new();

    private Transaction? _selected;
    public Transaction? SelectedTransaction
    {
        get => _selected;
        set { _selected = value; Notify(nameof(SelectedTransaction)); }
    }

    // Statistiky – aktualizují se po každé změně
    public string TotalIncome   => $"{_finance.TotalIncome():N2} Kč";
    public string TotalExpense  => $"{_finance.TotalExpense():N2} Kč";
    public string Balance       => $"{_finance.Balance():N2} Kč";
    public string BalanceStatus => _finance.IsInProfit() ? "✅ V plusu" : "❌ V mínusu";

    // Callbacky – Views je nastaví při otevření okna
    public Action? OpenAddWindow   { get; set; }
    public Action? OpenStatsWindow { get; set; }
    public Action<string>? ShowMsg { get; set; }

    public ICommand AddCommand        { get; }
    public ICommand DeleteCommand     { get; }
    public ICommand StatisticsCommand { get; }
    public ICommand ExportCommand     { get; }

    public MainWindowViewModel(FinanceService finance, FileService files)
    {
        _finance = finance;
        _files   = files;
        Refresh();

        AddCommand        = new RelayCommand(_ => OpenAddWindow?.Invoke());
        DeleteCommand     = new RelayCommand(_ => DeleteSelected());
        StatisticsCommand = new RelayCommand(_ => OpenStatsWindow?.Invoke());
        ExportCommand     = new RelayCommand(_ =>
        {
            var path = _files.ExportSummary(_finance.GetAll());
            ShowMsg?.Invoke($"Export uložen na plochu:\n{path}");
        });
    }

    // Načte/obnoví kolekci z FinanceService
    public void Refresh()
    {
        Transactions.Clear();
        foreach (var t in _finance.GetAll().OrderByDescending(t => t.Date))
            Transactions.Add(t);
        Notify(nameof(TotalIncome));
        Notify(nameof(TotalExpense));
        Notify(nameof(Balance));
        Notify(nameof(BalanceStatus));
    }

    private void DeleteSelected()
    {
        if (SelectedTransaction == null) return;
        _finance.Delete(SelectedTransaction.Id);
        Refresh();
    }

    public event PropertyChangedEventHandler? PropertyChanged;
    private void Notify(string n) =>
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(n));
}
