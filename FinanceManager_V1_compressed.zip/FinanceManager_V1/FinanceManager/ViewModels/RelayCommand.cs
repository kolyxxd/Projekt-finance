using System.Windows.Input;
using System;

namespace FinanceManager.ViewModels;

// Jednoduchá implementace ICommand – používáme ve všech ViewModelech
public class RelayCommand : ICommand
{
    private readonly Action<object?> _execute;
    private readonly Func<object?, bool>? _canExecute;

    public RelayCommand(Action<object?> execute, Func<object?, bool>? canExecute = null)
    {
        _execute    = execute;
        _canExecute = canExecute;
    }

    public bool CanExecute(object? p) => _canExecute?.Invoke(p) ?? true;
    public void Execute(object? p)    => _execute(p);
    public event EventHandler? CanExecuteChanged;
}
