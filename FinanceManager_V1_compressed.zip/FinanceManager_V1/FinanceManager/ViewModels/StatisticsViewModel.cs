using FinanceManager.Services;
using System.Collections.Generic;
using System.Linq;
namespace FinanceManager.ViewModels;

// ViewModel pro okno statistik – pouze čtení, žádné akce
public class StatisticsViewModel
{
    public string TotalIncome  => $"{_finance.TotalIncome():N2} Kč";
    public string TotalExpense => $"{_finance.TotalExpense():N2} Kč";
    public string Balance      => $"{_finance.Balance():N2} Kč";
    public string StatusText   => _finance.IsInProfit()
        ? "✅ Jsi v PLUSU – tak to má být!"
        : "❌ Jsi v MÍNUSU – pozor na výdaje!";

    // Výdaje seřazené od největší kategorie
    public List<string> CategoryLines { get; }

    private readonly FinanceService _finance;

    public StatisticsViewModel(FinanceService finance)
    {
        _finance = finance;
        CategoryLines = finance.ExpensesByCategory()
            .OrderByDescending(kv => kv.Value)
            .Select(kv => $"{kv.Key,-16}  {kv.Value:N2} Kč")
            .ToList();
    }
}
